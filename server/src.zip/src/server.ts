import app = require('./app');

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Code Academy Server running on port ${PORT}`);
});